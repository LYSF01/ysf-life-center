# L'YSF LIFE CENTER | Enterprise AI Management

Bu sistem, L'YSF Güzellik Merkezi için özel olarak tasarlanmış, Yapay Zeka destekli bir işletme yönetim üssüdür.

## 🚀 GitHub Üzerinden Çalıştırma (Hızlı Kurulum)

Bu uygulamayı bir web sitesi gibi her yerden açmak için şu adımları izleyin:

1. **Dosyaları İndirin:** Bu projedeki tüm dosyaları bilgisayarınıza indirin.
2. **GitHub'a Yükleyin:** 
   - GitHub profilinizde yeni bir "Repository" açın.
   - Dosyaları oraya sürükleyip bırakın.
3. **Yayına Alın (En İyi Yol):**
   - [Vercel.com](https://vercel.com) adresine gidin.
   - GitHub hesabınızla bağlanın.
   - Bu projeyi seçin ve "Deploy" butonuna basın.
   - Sistem size özel bir internet adresi (URL) verecektir.

## 🔒 Güvenlik Notları
- **Veriler:** Verileriniz hiçbir sunucuya yüklenmez, sadece o an kullandığınız tarayıcıda saklanır.
- **Şifre:** Yönetici paneli şifresi varsayılan olarak `LYSF2024` olarak ayarlanmıştır.
- **Yedekleme:** Başka bir cihaza geçmek isterseniz "Büyüme Merkezi" sekmesinden "Veriyi Yedekle" yapıp, yeni cihazda "Yedeği Yükle" demeniz yeterlidir.

## 🛠 Teknik Detaylar
- **Frontend:** React + Tailwind CSS + Lucide Icons
- **AI:** Google Gemini Pro & Flash
- **Analiz:** Recharts Financial Charts
