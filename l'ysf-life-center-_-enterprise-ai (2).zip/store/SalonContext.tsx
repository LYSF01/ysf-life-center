
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, Service, Customer, Staff, Transaction, UserRole, MembershipTier, Appointment, SessionPackage } from '../types';

interface SalonState {
  products: Product[];
  services: Service[];
  customers: Customer[];
  staff: Staff[];
  transactions: Transaction[];
  appointments: Appointment[];
  currentRole: UserRole;
  setRole: (role: UserRole) => void;
  isAuthenticated: boolean;
  login: (key: string) => boolean;
  logout: () => void;
  addProduct: (p: Product) => void;
  addCustomer: (c: Customer) => void;
  addAppointment: (a: Appointment) => void;
  deleteData: (id: string, type: 'PRODUCT' | 'CUSTOMER' | 'APPOINTMENT') => void;
  updateAppointmentStatus: (id: string, status: Appointment['status']) => void;
  completeSale: (customerId: string, staffId: string, items: any[]) => void;
  useSession: (customerId: string, packageId: string) => void;
  exportData: () => void;
  importData: (file: File) => Promise<boolean>;
  resetToDefaults: () => void;
}

const SalonContext = createContext<SalonState | undefined>(undefined);
const STORAGE_KEY = 'LYSF_SALON_DATA_V4';
const AUTH_KEY = 'LYSF_AUTH_STATUS';
const MASTER_PASSWORD = 'LYSF2024';

export const SalonProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(localStorage.getItem(AUTH_KEY) === 'true');
  const [currentRole, setRole] = useState<UserRole>(UserRole.MANAGER);
  const [products, setProducts] = useState<Product[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [staff, setStaff] = useState<Staff[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  useEffect(() => {
    const savedData = localStorage.getItem(STORAGE_KEY);
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData);
        setProducts(parsed.products || []);
        setServices(parsed.services || []);
        setCustomers(parsed.customers || []);
        setStaff(parsed.staff || []);
        setAppointments(parsed.appointments || []);
        setTransactions(parsed.transactions || []);
      } catch (e) {
        loadDefaults();
      }
    } else {
      loadDefaults();
    }
  }, []);

  useEffect(() => {
    const dataToSave = { products, services, customers, staff, appointments, transactions };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
  }, [products, services, customers, staff, appointments, transactions]);

  const loadDefaults = () => {
    setProducts([
      { id: 'p1', name: 'Hydrafacial Solüsyon Seti', category: 'SKIN_CARE', stock: 10, costPrice: 2000, salePrice: 5000, unit: 'set', wasteThreshold: 1, lastAuditDate: '' },
      { id: 'p2', name: 'Protez Tırnak Jeli Professional', category: 'NAIL', stock: 25, costPrice: 400, salePrice: 1500, unit: 'adet', wasteThreshold: 2, lastAuditDate: '' }
    ]);
    setServices([
      { id: 's1', name: 'Hydrafacial Cilt Bakımı', category: 'SKIN_CARE', duration: 60, price: 2500, commissionRate: 15, overheadCost: 300 },
      { id: 's2', name: 'G5 Masajı (Tek Seans)', category: 'SKIN_CARE', duration: 45, price: 1200, commissionRate: 10, overheadCost: 100 },
      { id: 's3', name: 'Protez Tırnak (Yeni Set)', category: 'NAIL', duration: 120, price: 1800, commissionRate: 20, overheadCost: 150 },
      { id: 's4', name: 'Nail Art (Tırnak Süsleme)', category: 'NAIL', duration: 30, price: 400, commissionRate: 25, overheadCost: 20 },
      { id: 's5', name: 'Diyetisyen İlk Muayene', category: 'DIET', duration: 45, price: 1500, commissionRate: 30, overheadCost: 50 },
      { id: 's6', name: 'Lazer Epilasyon (Tüm Vücut)', category: 'SKIN_CARE', duration: 90, price: 4500, commissionRate: 10, overheadCost: 600 }
    ]);
    setStaff([
      { id: 'st1', name: 'Yusuf Bey', role: 'Yönetici', totalPrim: 0, salesCount: 0 },
      { id: 'st2', name: 'Uzman Ayşe', role: 'Estetisyen', totalPrim: 0, salesCount: 0 },
      { id: 'st3', name: 'Dyt. Merve', role: 'Diyetisyen', totalPrim: 0, salesCount: 0 }
    ]);
    setCustomers([
      {
        id: 'c1',
        fullName: 'Ayşe Hanım',
        phone: '05321112233',
        tcNo: '12345678901',
        tier: MembershipTier.GOLD,
        walletBalance: 0,
        totalSpent: 12000,
        points: 1200,
        packages: [
          { id: 'pkg1', serviceId: 's2', totalSessions: 10, remainingSessions: 7, purchaseDate: '2024-05-01' }
        ],
        bodyAnalysis: { weight: '65', fatRatio: '24', targetWeight: '58', lastUpdate: '2024-05-15' },
        preferences: { music: 'Slow', drink: 'Yeşil Çay', notes: 'G5 işleminde hassas.' },
        history: ['2024-05-01 - 10 Seans G5 Paketi Satın Alındı']
      }
    ]);
  };

  const login = (key: string) => {
    if (key === MASTER_PASSWORD) {
      setIsAuthenticated(true);
      localStorage.setItem(AUTH_KEY, 'true');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem(AUTH_KEY);
  };

  const addProduct = (p: Product) => setProducts(prev => [...prev, p]);
  const addCustomer = (c: Customer) => setCustomers(prev => [...prev, c]);
  const addAppointment = (a: Appointment) => setAppointments(prev => [...prev, a]);

  const deleteData = (id: string, type: 'PRODUCT' | 'CUSTOMER' | 'APPOINTMENT') => {
    if (currentRole !== UserRole.MANAGER) return;
    if (type === 'PRODUCT') setProducts(prev => prev.filter(p => p.id !== id));
    if (type === 'CUSTOMER') setCustomers(prev => prev.filter(c => c.id !== id));
    if (type === 'APPOINTMENT') setAppointments(prev => prev.filter(a => a.id !== id));
  };

  const updateAppointmentStatus = (id: string, status: Appointment['status']) => {
    setAppointments(prev => prev.map(a => a.id === id ? { ...a, status } : a));
  };

  const useSession = (customerId: string, packageId: string) => {
    setCustomers(prev => prev.map(c => {
      if (c.id === customerId) {
        return {
          ...c,
          packages: c.packages.map(p => {
            if (p.id === packageId && p.remainingSessions > 0) {
              return { ...p, remainingSessions: p.remainingSessions - 1 };
            }
            return p;
          }),
          history: [...c.history, `${new Date().toLocaleDateString()} - 1 Seans Paket Kullanıldı`]
        };
      }
      return c;
    }));
  };

  const completeSale = (customerId: string, staffId: string, items: any[]) => {
    let total = 0; let profit = 0; let comm = 0;
    
    const updatedPackages: SessionPackage[] = [];

    items.forEach(item => {
      total += item.price * item.quantity;
      if (item.type === 'SERVICE') {
        const s = services.find(x => x.id === item.id);
        if (s) {
          const p = (item.price * s.commissionRate) / 100;
          comm += p; profit += (item.price - s.overheadCost - p);
        }
      } else if (item.type === 'PACKAGE') {
        const s = services.find(x => x.id === item.id);
        if (s) {
          updatedPackages.push({
            id: Math.random().toString(36).substr(2, 9),
            serviceId: s.id,
            totalSessions: item.sessions || 10,
            remainingSessions: item.sessions || 10,
            purchaseDate: new Date().toISOString()
          });
          const p = (item.price * s.commissionRate) / 100;
          comm += p; profit += (item.price - s.overheadCost - p);
        }
      }
    });

    setTransactions(prev => [...prev, { id: Date.now().toString(), customerId, staffId, items, totalAmount: total, netProfit: profit, commissionPaid: comm, timestamp: new Date().toISOString() }]);
    
    setCustomers(prev => prev.map(c => {
      if (c.id === customerId) {
        return { 
          ...c, 
          totalSpent: c.totalSpent + total, 
          packages: [...c.packages, ...updatedPackages],
          history: [...c.history, `${new Date().toLocaleDateString()} - Satış: ${total} TL`] 
        };
      }
      return c;
    }));

    setStaff(prev => prev.map(s => {
      if (s.id === staffId) {
        return { ...s, totalPrim: s.totalPrim + comm, salesCount: s.salesCount + 1 };
      }
      return s;
    }));
  };

  const exportData = () => {
    const data = { products, services, customers, staff, appointments, transactions };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LYSF_DATA_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importData = (file: File): Promise<boolean> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target?.result as string);
          if (data.customers) setCustomers(data.customers);
          if (data.products) setProducts(data.products);
          if (data.services) setServices(data.services);
          if (data.staff) setStaff(data.staff);
          if (data.appointments) setAppointments(data.appointments);
          if (data.transactions) setTransactions(data.transactions);
          resolve(true);
        } catch (err) {
          resolve(false);
        }
      };
      reader.readAsText(file);
    });
  };

  const resetToDefaults = () => {
    if (confirm("Tüm veriler silinecek ve fabrika ayarlarına dönülecek. Emin misiniz?")) {
      loadDefaults();
      localStorage.removeItem(STORAGE_KEY);
      window.location.reload();
    }
  };

  return (
    <SalonContext.Provider value={{
      products, services, customers, staff, transactions, appointments, currentRole, setRole,
      isAuthenticated, login, logout, addProduct, addCustomer, addAppointment, deleteData, 
      updateAppointmentStatus, completeSale, useSession, exportData, importData, resetToDefaults
    }}>
      {children}
    </SalonContext.Provider>
  );
};

export const useSalon = () => {
  const context = useContext(SalonContext);
  if (!context) throw new Error("useSalon error");
  return context;
};
