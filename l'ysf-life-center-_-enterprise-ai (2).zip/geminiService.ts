
import { GoogleGenAI, Type } from "@google/genai";
import { Product, Service, Customer } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// AI treatment assistant with "Expert Protocol"
export const getAITreatmentProtocol = async (condition: string, products: Product[], services: Service[]) => {
  const prompt = `
    İŞLETME: L'YSF LIFE CENTER (Ultra-Luxury & Medical)
    UZMAN NOTU: ${condition}
    ENVANTER: ${JSON.stringify(products.map(p => p.name))}
    HİZMETLER: ${JSON.stringify(services.map(s => s.name))}

    GÖREV: Alman disipliniyle, A'dan Z'ye bir seans protokolü hazırla.
    1. Hangi cihaz kaç dakika kullanılacak?
    2. Hangi ürün hangi sırayla sürülecek?
    3. Müşteriye tablet ekranında gösterilecek 'Lüks Deneyim' mesajı ne olmalı?
    4. Seans sonrası kârı artırmak için hangi ürünü (upsell) önermeliyiz?
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt
  });
  return response.text;
};

// AI Financial Auditor (Detects leaks and theft)
export const getAuditReport = async (transactions: any[], products: Product[]) => {
  const prompt = `
    Sen L'YSF LIFE CENTER'ın finans denetçisisin. 
    İşlemler: ${JSON.stringify(transactions)}
    Ürün Stokları: ${JSON.stringify(products)}
    
    Analiz et: Seans sayıları ile ürün tüketimi uyumlu mu? Stokta açıklanamayan bir düşüş var mı? 
    Hangi personel verimlilikte geride? Kâr oranını %20 artırmak için hangi fiyat revizyonu yapılmalı?
  `;
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt
  });
  return response.text;
};

// Global trend analyzer
export const getGlobalMarketIntelligence = async () => {
  const prompt = `
    Güzellik Sektörü 2024-2025 Trend Analizi (Berlin, NYC, Istanbul):
    L'YSF LIFE CENTER için hangi yeni cihaz yatırımı yapılmalı? 
    Hangi hizmetlerde fiyat artışı (zammı) pazar tarafından kabul edilir?
    Rakiplerin önüne geçecek 'Elite' hizmet önerileri nelerdir?
  `;
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt
  });
  return response.text;
};

// AI-driven package generator for high profit margins
export const getAIPackageSuggestions = async (services: Service[], products: Product[]) => {
  const prompt = `
    L'YSF LIFE CENTER için yüksek kâr marjlı kampanya paketleri oluştur. 
    Mevcut Hizmetler: ${JSON.stringify(services)}
    Mevcut Ürünler: ${JSON.stringify(products)}
    
    Yapay zeka olarak, en popüler hizmetleri ve stoktaki ürünleri birleştirerek 3 adet özel paket öner.
    Fiyatlandırma, içerik ve pazarlama taktiği içermeli.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          packages: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING, description: "Paket ismi" },
                content: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Paket içeriğindeki hizmet/ürünler" },
                regularPrice: { type: Type.NUMBER, description: "Normal liste fiyatı" },
                customerPrice: { type: Type.NUMBER, description: "Müşteriye sunulan indirimli fiyat" },
                managerCost: { type: Type.NUMBER, description: "İşletmeye olan toplam maliyet" },
                psychologicalTactic: { type: Type.STRING, description: "Satışı artıracak psikolojik argüman" }
              },
              required: ["name", "content", "regularPrice", "customerPrice", "managerCost", "psychologicalTactic"]
            }
          }
        },
        required: ["packages"]
      }
    }
  });

  try {
    const text = response.text || '{"packages": []}';
    return JSON.parse(text);
  } catch (e) {
    return { packages: [] };
  }
};
