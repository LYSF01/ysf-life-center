
export enum UserRole {
  MANAGER = 'MANAGER',
  STAFF = 'STAFF',
  CUSTOMER = 'CUSTOMER'
}

export enum MembershipTier {
  BRONZE = 'BRONZE',
  SILVER = 'SILVER',
  GOLD = 'GOLD',
  PLATINUM = 'PLATINUM',
  BLACK_VIP = 'BLACK_VIP'
}

export interface SessionPackage {
  id: string;
  serviceId: string;
  totalSessions: number;
  remainingSessions: number;
  purchaseDate: string;
}

export interface Product {
  id: string;
  name: string;
  category: 'SKIN_CARE' | 'NAIL' | 'DIET' | 'GENERAL';
  stock: number;
  costPrice: number;
  salePrice: number;
  unit: string;
  wasteThreshold: number;
  lastAuditDate: string;
}

export interface Service {
  id: string;
  name: string;
  category: 'SKIN_CARE' | 'NAIL' | 'DIET' | 'GENERAL';
  duration: number;
  price: number;
  commissionRate: number; 
  overheadCost: number;   
}

export interface Appointment {
  id: string;
  customerId: string;
  serviceId: string;
  staffId: string;
  date: string;
  time: string;
  status: 'PENDING' | 'COMPLETED' | 'CANCELLED';
  reminderSent: boolean;
}

export interface Customer {
  id: string;
  fullName: string;
  phone: string;
  tcNo: string;
  tier: MembershipTier;
  walletBalance: number;
  totalSpent: number;
  points: number;
  packages: SessionPackage[];
  bodyAnalysis?: {
    weight: string;
    fatRatio: string;
    targetWeight: string;
    lastUpdate: string;
  };
  preferences: {
    music: string;
    drink: string;
    notes: string;
  };
  history: string[];
}

export interface Transaction {
  id: string;
  customerId: string;
  staffId: string;
  items: { type: 'PRODUCT' | 'SERVICE' | 'PACKAGE'; id: string; price: number; quantity: number }[];
  totalAmount: number;
  netProfit: number;
  commissionPaid: number;
  timestamp: string;
}

export interface Staff {
  id: string;
  name: string;
  role: string;
  totalPrim: number;
  salesCount: number;
}
