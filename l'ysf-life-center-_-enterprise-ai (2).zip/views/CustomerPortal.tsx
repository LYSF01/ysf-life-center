
import React, { useState } from 'react';
import { useSalon } from '../store/SalonContext';
import { Star, CreditCard, ShieldCheck, ArrowRight, Sparkles, TrendingUp, History } from 'lucide-react';

export const CustomerPortal: React.FC = () => {
  const { customers } = useSalon();
  const [phone, setPhone] = useState('');
  const [tc, setTc] = useState('');
  const [loggedIn, setLoggedIn] = useState(false);
  const [showConsent, setShowConsent] = useState(false);
  
  // Login simülasyonu (Telefon numarasının son hanesine göre müşteri bul)
  const currentCustomer = customers[0]; 

  const handleLogin = () => {
    if (phone.length >= 10 && tc.length === 11 && showConsent) {
      setLoggedIn(true);
    } else {
      alert("Lütfen T.C., Telefon ve KVKK onayını eksiksiz doldurun!");
    }
  };

  if (!loggedIn) {
    return (
      <div className="flex items-center justify-center min-h-[85vh] p-4">
        <div className="max-w-2xl w-full p-16 bg-white rounded-[4rem] shadow-3xl border border-slate-100 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-3 bg-gradient-to-r from-rose-500 via-amber-500 to-indigo-500"></div>
          <h1 className="text-6xl font-black text-slate-900 mb-2 tracking-tighter">L'YSF</h1>
          <p className="text-rose-500 font-black mb-12 tracking-[0.5em] uppercase text-sm">Life Center Elite Portal</p>
          
          <div className="space-y-8 text-left">
            <div>
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-4 mb-2 block">GSM Numarası (Zorunlu)</label>
              <input 
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="05XX XXX XX XX"
                className="w-full p-6 text-2xl font-black bg-slate-50 rounded-3xl border-2 border-transparent focus:border-rose-400 outline-none transition-all"
              />
            </div>
            <div>
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-4 mb-2 block">T.C. Kimlik No (Zorunlu)</label>
              <input 
                type="text"
                maxLength={11}
                value={tc}
                onChange={(e) => setTc(e.target.value)}
                placeholder="XXXXXXXXXXX"
                className="w-full p-6 text-2xl font-black bg-slate-50 rounded-3xl border-2 border-transparent focus:border-rose-400 outline-none transition-all"
              />
            </div>

            <div className="flex items-center gap-4 p-6 bg-slate-50 rounded-[2rem] cursor-pointer" onClick={() => setShowConsent(!showConsent)}>
              <div className={`w-8 h-8 rounded-xl border-2 flex items-center justify-center transition-all ${showConsent ? 'bg-emerald-500 border-emerald-500' : 'bg-white border-slate-200'}`}>
                {showConsent && <ShieldCheck size={18} className="text-white" />}
              </div>
              <p className="text-xs text-slate-500 font-bold leading-relaxed uppercase tracking-tight">KVKK Aydınlatma Metnini, Özel Tercihlerin İşlenmesini ve Kampanya Bildirimlerini Onaylıyorum.</p>
            </div>

            <button 
              onClick={handleLogin}
              className="w-full bg-slate-900 hover:bg-black text-white font-black py-8 rounded-[2.5rem] text-2xl shadow-2xl transition-all active:scale-95 flex items-center justify-center gap-4"
            >
              Hemen Başlayalım <ArrowRight size={32} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-12 py-10 animate-in zoom-in-95 duration-500">
      {/* Black VIP Card */}
      <div className="relative overflow-hidden bg-slate-900 rounded-[4rem] p-16 text-white shadow-3xl">
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="text-center md:text-left flex-1">
            <span className="px-6 py-2 bg-rose-500/20 text-rose-400 text-xs font-black uppercase tracking-[0.5em] rounded-full border border-rose-400/30 mb-8 inline-block">
              {currentCustomer.tier.replace('_', ' ')} MEMBER
            </span>
            <h2 className="text-7xl font-black mb-6 tracking-tighter leading-none">{currentCustomer.fullName}</h2>
            <div className="flex flex-wrap items-center gap-8 text-slate-400 justify-center md:justify-start">
              <span className="flex items-center gap-2"><Star size={20} className="text-amber-400 fill-amber-400" /> {currentCustomer.points} Sadakat Puanı</span>
              <span className="w-1.5 h-1.5 bg-slate-700 rounded-full"></span>
              <span className="flex items-center gap-2"><CreditCard size={20} /> Cüzdan Bakiyesi: {currentCustomer.walletBalance.toLocaleString()} TL</span>
            </div>
          </div>
          
          <div className="flex gap-6">
            <div className="w-48 h-48 bg-white/5 backdrop-blur-3xl rounded-[3rem] border border-white/10 flex flex-col items-center justify-center group hover:bg-white/10 transition-all">
              <p className="text-[11px] text-slate-500 uppercase font-black tracking-widest mb-2">Sadakat</p>
              <p className="text-4xl font-black text-rose-500">Tier 4</p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-12">
          {/* Progress & Goals */}
          <div className="bg-white p-12 rounded-[4rem] shadow-sm border border-slate-100">
            <h3 className="text-3xl font-black mb-10 flex items-center gap-4">
              <TrendingUp className="text-rose-500" /> İyileşme Timeline
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="p-8 bg-slate-50 rounded-[2.5rem]">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-5">Cilt Kalite Oranı</p>
                <div className="w-full h-5 bg-slate-200 rounded-full overflow-hidden">
                  <div className="w-[88%] h-full bg-emerald-500 shadow-lg"></div>
                </div>
                <p className="mt-5 text-4xl font-black text-slate-800">%88 <span className="text-sm text-emerald-500 font-bold">+2.4% Artış</span></p>
              </div>
              <div className="p-8 bg-slate-50 rounded-[2.5rem]">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-5">Diyet Uyumu</p>
                <div className="w-full h-5 bg-slate-200 rounded-full overflow-hidden">
                  <div className="w-[65%] h-full bg-rose-500 shadow-lg"></div>
                </div>
                <p className="mt-5 text-4xl font-black text-slate-800">%65 <span className="text-sm text-rose-500 font-bold">Hızlanma Gerekli</span></p>
              </div>
            </div>
          </div>

          {/* History */}
          <div className="bg-white p-12 rounded-[4rem] shadow-sm border border-slate-100">
            <h3 className="text-3xl font-black mb-10 flex items-center gap-4">
               <History className="text-indigo-500" /> İşlem Geçmişi
            </h3>
            <div className="space-y-6">
              {currentCustomer.history.map((h, i) => (
                <div key={i} className="flex items-center gap-8 p-8 bg-slate-50 rounded-[2.5rem] border border-transparent hover:border-rose-100 transition-all">
                  <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center font-black text-slate-200 text-3xl">#{i+1}</div>
                  <div className="flex-1">
                    <p className="text-2xl font-black text-slate-800">{h.split(' - ')[1]}</p>
                    <p className="text-sm font-bold text-slate-400">{h.split(' - ')[0]}</p>
                  </div>
                  <div className="p-5 bg-emerald-50 rounded-2xl text-emerald-600 font-black text-sm uppercase tracking-widest">Başarılı</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI Sidebar */}
        <div className="space-y-12">
          <div className="bg-gradient-to-br from-rose-500 to-rose-900 p-12 rounded-[4rem] text-white shadow-3xl h-full flex flex-col justify-center relative overflow-hidden">
            <Sparkles className="mb-10 opacity-30" size={64} />
            <h4 className="text-5xl font-black mb-8 leading-[0.9]">AI Güzellik Danışmanı</h4>
            <p className="text-rose-100 mb-12 text-xl leading-relaxed font-medium">Analizimize göre; son cilt bakım seansınızdan sonra <span className="text-white font-black underline">Gold Serum</span> kullanımı kalıcılığı %40 artıracaktır.</p>
            <button className="w-full bg-white text-rose-900 font-black py-6 rounded-3xl shadow-2xl hover:scale-[1.05] transition-transform text-xl uppercase tracking-widest">
              Özel Teklifi Al
            </button>
            <div className="absolute -bottom-16 -right-16 w-64 h-64 bg-white/10 rounded-full blur-[100px]"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
