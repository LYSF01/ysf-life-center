
import React, { useState } from 'react';
import { useSalon } from '../store/SalonContext';
import { getAuditReport } from '../geminiService';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, DollarSign, ShieldAlert, Zap, Users, ShieldCheck, Share2, Smartphone, Monitor, Copy, Check, Cloud, Info, HelpCircle } from 'lucide-react';

export const ManagerDashboard: React.FC = () => {
  const { transactions, products, customers, exportData } = useSalon();
  const [auditText, setAuditText] = useState<string | null>(null);
  const [loadingAudit, setLoadingAudit] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showHelp, setShowHelp] = useState(false);

  const totalRevenue = transactions.reduce((acc, t) => acc + t.totalAmount, 0);
  const totalNetProfit = transactions.reduce((acc, t) => acc + t.netProfit, 0);

  const handleAudit = async () => {
    setLoadingAudit(true);
    const report = await getAuditReport(transactions, products);
    setAuditText(report);
    setLoadingAudit(false);
  };

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      {/* GLOBAL BULUT ERİŞİM BANDI */}
      <div className="bg-gradient-to-r from-indigo-700 via-purple-700 to-indigo-800 rounded-[2.5rem] p-10 text-white shadow-2xl flex flex-col lg:flex-row items-center justify-between gap-10 border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
            <Cloud size={180} />
        </div>
        
        <div className="flex items-center gap-8 relative z-10">
          <div className="w-20 h-20 bg-white/20 rounded-3xl flex items-center justify-center backdrop-blur-2xl border border-white/20 shadow-inner">
            <Share2 size={36} className="text-amber-400" />
          </div>
          <div>
            <h3 className="text-3xl font-black tracking-tight">Dükkan Erişim Linkiniz</h3>
            <p className="text-indigo-100 text-sm font-medium mt-1">Bu linki kopyalayıp tabletinize gönderin. Her yerden yönetin.</p>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center gap-4 w-full lg:w-auto relative z-10">
          <div className="bg-black/40 px-8 py-5 rounded-2xl border border-white/10 flex items-center gap-6 flex-1 lg:min-w-[400px] shadow-lg">
            <code className="text-xs font-bold text-amber-300 truncate tracking-wider">{window.location.href}</code>
            <button 
              onClick={copyLink}
              className="p-3 bg-white text-indigo-700 rounded-xl hover:scale-110 transition-all shadow-md active:scale-95"
              title="Link Kopyala"
            >
              {copied ? <Check size={20} /> : <Copy size={20} />}
            </button>
          </div>
          <button 
            onClick={() => setShowHelp(!showHelp)}
            className="bg-white/10 hover:bg-white/20 text-white px-6 py-5 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 border border-white/10 transition-all"
          >
            <HelpCircle size={18} /> Yardım
          </button>
        </div>
      </div>

      {showHelp && (
          <div className="bg-amber-50 border-2 border-amber-200 p-8 rounded-[2.5rem] animate-in slide-in-from-top-4">
              <div className="flex items-start gap-4">
                  <Info className="text-amber-600 mt-1" size={24} />
                  <div className="space-y-4">
                      <h4 className="text-lg font-black text-amber-900">Neden Link Erişilemiyor Hatası Alıyorum?</h4>
                      <p className="text-sm text-amber-800 leading-relaxed font-medium">
                          1. <b>Link Farklı, Veri Farklı:</b> Yukarıdaki link uygulamanın kendisidir. Verileriniz ise güvenliğiniz için tarayıcınızda saklanır.<br/>
                          2. <b>Nasıl Eşitlerim?</b> Bilgisayardan işlem yaptıysanız, "Buluta Yedekle" butonuna basın. Bir dosya inecek. Bu dosyayı mail veya WhatsApp ile tabletinize gönderin.<br/>
                          3. <b>Tablette Açın:</b> Tabletinizden bu linke girin, "Büyüme Merkezi" (AI Advice) sekmesine gidin ve "Veriyi Yükle" diyerek dosyayı seçin. Artık her iki cihaz da aynı olur!
                      </p>
                  </div>
              </div>
          </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Toplam Ciro" value={`${totalRevenue.toLocaleString()} TL`} icon={DollarSign} color="rose" />
        <StatCard title="Net Kâr" value={`${totalNetProfit.toLocaleString()} TL`} icon={TrendingUp} color="emerald" />
        <StatCard title="VIP Müşteri" value={customers.length.toString()} icon={ShieldCheck} color="amber" />
        <StatCard title="Veri Durumu" value="Cihaza Kayıtlı" icon={Cloud} color="indigo" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-10">
        <div className="xl:col-span-2 space-y-8">
          <div className="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
            <div className="flex justify-between items-center mb-10">
                <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3">
                <Zap className="text-rose-500" /> Finansal Performans
                </h3>
                <div className="flex gap-2">
                    <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                    <div className="w-3 h-3 rounded-full bg-indigo-500"></div>
                </div>
            </div>
            <div className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={transactions.length > 0 ? transactions.map(t => ({ date: t.timestamp.split('T')[0], revenue: t.totalAmount, profit: t.netProfit })) : [
                  { date: 'Pzt', revenue: 4500, profit: 2800 },
                  { date: 'Sal', revenue: 3200, profit: 1800 },
                  { date: 'Çar', revenue: 6700, profit: 4200 },
                  { date: 'Per', revenue: 5500, profit: 3100 },
                ]}>
                  <defs>
                    <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11}} />
                  <Tooltip contentStyle={{borderRadius: '20px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}} />
                  <Area type="monotone" dataKey="profit" stroke="#10b981" fillOpacity={1} fill="url(#colorProfit)" strokeWidth={4} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="bg-slate-900 rounded-[3rem] p-10 text-white shadow-2xl flex flex-col relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <ShieldAlert size={120} />
          </div>
          <div className="relative z-10 flex flex-col h-full">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 bg-rose-500 rounded-2xl flex items-center justify-center shadow-lg shadow-rose-500/30">
                <ShieldAlert size={24} />
              </div>
              <h3 className="text-xl font-black">Yapay Zeka Denetçisi</h3>
            </div>
            <div className="flex-1 bg-white/5 rounded-[2rem] p-6 mb-8 overflow-y-auto text-sm leading-relaxed text-slate-300 italic border border-white/10 scrollbar-hide">
              {auditText ? auditText : "Kasanızı, stoklarınızı ve personel performansınızı analiz etmek için hazırım. Alman disipliniyle sızıntıları raporlarım."}
            </div>
            <button 
                onClick={handleAudit} 
                disabled={loadingAudit} 
                className="w-full py-6 bg-rose-500 hover:bg-rose-600 rounded-2xl font-black transition-all shadow-xl active:scale-95 flex items-center justify-center gap-3"
            >
              {loadingAudit ? "Analiz Ediliyor..." : "Hemen Denetle"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, icon: Icon, color }: any) => {
  const colors = {
    rose: 'text-rose-500 bg-rose-50',
    emerald: 'text-emerald-500 bg-emerald-50',
    indigo: 'text-indigo-500 bg-indigo-50',
    amber: 'text-amber-500 bg-amber-50'
  } as any;
  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:-translate-y-1 transition-all duration-300">
      <div className={`w-14 h-14 ${colors[color]} rounded-2xl flex items-center justify-center mb-6 shadow-sm`}>
        <Icon size={28} />
      </div>
      <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-2">{title}</p>
      <p className="text-2xl font-black text-slate-900">{value}</p>
    </div>
  );
};
