
import React, { useState } from 'react';
import { useSalon } from '../store/SalonContext';
import { Calendar, Clock, MessageSquare, Plus, Trash2, X, User, Activity } from 'lucide-react';

export const Appointments: React.FC = () => {
  const { appointments, customers, services, staff, addAppointment, updateAppointmentStatus, deleteData, currentRole } = useSalon();
  const [showForm, setShowForm] = useState(false);
  const [newApp, setNewApp] = useState({ customerId: '', serviceId: '', staffId: '', date: '', time: '' });

  const handleAdd = () => {
    if(!newApp.customerId || !newApp.date) return;
    addAppointment({
      id: Math.random().toString(36).substr(2, 9),
      ...newApp,
      status: 'PENDING',
      reminderSent: false
    });
    setShowForm(false);
  };

  const handleNotify = (phone: string) => {
    alert(`WhatsApp Mesajı İletildi: \n"L'YSF Life Center: Sayın müşterimiz, bugün randevunuz bulunmaktadır. Sizi bekliyoruz."`);
  };

  return (
    <div className="space-y-10">
      <div className="bg-white rounded-[3.5rem] shadow-xl border border-slate-100 overflow-hidden">
        <div className="p-10 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
          <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3">
            <Calendar className="text-rose-500" /> Bugünün Randevu Planı
          </h3>
          <button 
            onClick={() => setShowForm(true)}
            className="bg-slate-900 text-white px-8 py-4 rounded-[1.5rem] font-black text-xs uppercase tracking-widest shadow-xl flex items-center gap-2 hover:bg-black transition-all"
          >
            <Plus size={16} /> Yeni Randevu Oluştur
          </button>
        </div>

        <div className="divide-y divide-slate-100">
          {appointments.map(app => {
            const customer = customers.find(c => c.id === app.customerId);
            const service = services.find(s => s.id === app.serviceId);
            const staffMember = staff.find(s => s.id === app.staffId);

            return (
              <div key={app.id} className="p-10 flex flex-col lg:flex-row items-center justify-between gap-8 group hover:bg-slate-50/50 transition-all">
                <div className="flex items-center gap-10">
                  <div className="text-center bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm min-w-[120px]">
                    <p className="text-3xl font-black text-slate-900">{app.time}</p>
                    <p className="text-[10px] font-black text-rose-500 uppercase tracking-widest mt-1">{app.date}</p>
                  </div>
                  <div>
                    <h4 className="text-2xl font-black text-slate-900 tracking-tighter">{customer?.fullName}</h4>
                    <p className="text-sm font-bold text-indigo-600 uppercase tracking-widest mt-1">{service?.name}</p>
                    <p className="text-xs text-slate-400 font-bold mt-1">Uzman: {staffMember?.name}</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <button onClick={() => handleNotify(customer?.phone || '')} className="flex items-center gap-2 px-8 py-4 bg-emerald-50 text-emerald-600 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-emerald-100 transition-all">
                    <MessageSquare size={16} /> WhatsApp Hatırlat
                  </button>
                  {app.status === 'PENDING' ? (
                    <button onClick={() => updateAppointmentStatus(app.id, 'COMPLETED')} className="px-8 py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg">Tamamla</button>
                  ) : (
                    <span className="bg-emerald-100 text-emerald-700 px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-widest">Seans Yapıldı</span>
                  )}
                  {currentRole === 'MANAGER' && (
                    <button onClick={() => deleteData(app.id, 'APPOINTMENT')} className="p-4 text-slate-300 hover:text-rose-500 transition-colors">
                      <Trash2 size={20} />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Randevu Ekleme Modalı */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4">
          <div className="bg-white w-full max-w-xl rounded-[3rem] p-10 shadow-3xl">
            <div className="flex justify-between items-center mb-10">
              <h3 className="text-2xl font-black">Randevu Oluştur</h3>
              <button onClick={() => setShowForm(false)} className="p-2 hover:bg-slate-100 rounded-full"><X /></button>
            </div>
            <div className="space-y-6">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block">Müşteri Seç</label>
                <select value={newApp.customerId} onChange={e => setNewApp({...newApp, customerId: e.target.value})} className="w-full p-4 bg-slate-50 rounded-2xl border border-slate-200 font-bold">
                  <option value="">Seçiniz...</option>
                  {customers.map(c => <option key={c.id} value={c.id}>{c.fullName}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block">Hizmet</label>
                  <select value={newApp.serviceId} onChange={e => setNewApp({...newApp, serviceId: e.target.value})} className="w-full p-4 bg-slate-50 rounded-2xl border border-slate-200 font-bold">
                    <option value="">Seçiniz...</option>
                    {services.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block">Uzman</label>
                  <select value={newApp.staffId} onChange={e => setNewApp({...newApp, staffId: e.target.value})} className="w-full p-4 bg-slate-50 rounded-2xl border border-slate-200 font-bold">
                    <option value="">Seçiniz...</option>
                    {staff.map(st => <option key={st.id} value={st.id}>{st.name}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block">Tarih</label>
                  <input type="date" onChange={e => setNewApp({...newApp, date: e.target.value})} className="w-full p-4 bg-slate-50 rounded-2xl border border-slate-200 font-bold" />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block">Saat</label>
                  <input type="time" onChange={e => setNewApp({...newApp, time: e.target.value})} className="w-full p-4 bg-slate-50 rounded-2xl border border-slate-200 font-bold" />
                </div>
              </div>
              <button onClick={handleAdd} className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-lg hover:bg-black transition-all">Randevuyu Kaydet</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
