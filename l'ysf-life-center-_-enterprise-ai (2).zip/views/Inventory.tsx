
import React, { useState } from 'react';
import { useSalon } from '../store/SalonContext';
import { UserRole } from '../types';
import { Package, Plus, Search, Trash2, TrendingUp, DollarSign, X } from 'lucide-react';

export const Inventory: React.FC = () => {
  const { products, currentRole, deleteData, addProduct } = useSalon();
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  
  // Yeni Ürün Form State
  const [newProd, setNewProd] = useState({ name: '', cost: 0, sale: 0, stock: 0 });

  const isManager = currentRole === UserRole.MANAGER;
  const filteredProducts = products.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));

  const handleAdd = () => {
    if(!newProd.name || newProd.cost <= 0) return;
    addProduct({
      id: Math.random().toString(36).substr(2, 9),
      name: newProd.name,
      category: 'GENERAL',
      stock: newProd.stock,
      costPrice: newProd.cost,
      salePrice: newProd.sale,
      unit: 'adet',
      wasteThreshold: 1,
      lastAuditDate: new Date().toISOString()
    });
    setNewProd({ name: '', cost: 0, sale: 0, stock: 0 });
    setShowForm(false);
  };

  return (
    <div className="space-y-10">
      {/* Header & Search */}
      <div className="flex flex-col lg:flex-row justify-between items-center gap-8">
        <div className="relative w-full lg:w-[600px]">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={24} />
          <input 
            type="text"
            placeholder="Ürün veya demirbaş ara..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-16 pr-8 py-6 bg-white border border-slate-200 rounded-[2.5rem] shadow-sm focus:ring-4 focus:ring-rose-500/10 outline-none transition-all font-black"
          />
        </div>
        {isManager && (
          <button 
            onClick={() => setShowForm(true)}
            className="w-full lg:w-auto bg-slate-900 text-white px-12 py-6 rounded-[2.5rem] font-black shadow-2xl hover:scale-105 transition-all flex items-center justify-center gap-3"
          >
            <Plus size={24} /> Yeni Stok Ekle
          </button>
        )}
      </div>

      {/* Stok Tablosu */}
      <div className="bg-white rounded-[3.5rem] shadow-xl border border-slate-100 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-900 text-slate-400 text-[10px] font-black uppercase tracking-widest">
            <tr>
              <th className="px-10 py-8">Ürün Detayı</th>
              <th className="px-10 py-8 text-center">Stok</th>
              {isManager && <th className="px-10 py-8 text-right text-rose-400">Geliş (Maliyet)</th>}
              <th className="px-10 py-8 text-right text-emerald-400">Satış</th>
              {isManager && <th className="px-10 py-8 text-center">Kâr Oranı</th>}
              {isManager && <th className="px-10 py-8 text-right">İşlem</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredProducts.map(p => (
              <tr key={p.id} className="hover:bg-slate-50 transition-all group">
                <td className="px-10 py-8">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center text-slate-400 group-hover:bg-rose-500 group-hover:text-white transition-all">
                      <Package size={20} />
                    </div>
                    <p className="font-black text-slate-900">{p.name}</p>
                  </div>
                </td>
                <td className="px-10 py-8 text-center">
                  <span className={`text-xl font-black ${p.stock < 10 ? 'text-rose-500 animate-pulse' : 'text-slate-900'}`}>{p.stock}</span>
                </td>
                {isManager && <td className="px-10 py-8 text-right font-black text-slate-400">{p.costPrice} TL</td>}
                <td className="px-10 py-8 text-right font-black text-slate-900 text-xl">{p.salePrice} TL</td>
                {isManager && (
                  <td className="px-10 py-8 text-center">
                    <span className="bg-emerald-50 text-emerald-600 px-4 py-2 rounded-xl font-black text-xs">
                      %{Math.round(((p.salePrice - p.costPrice) / p.costPrice) * 100)}
                    </span>
                  </td>
                )}
                {isManager && (
                  <td className="px-10 py-8 text-right">
                    <button onClick={() => deleteData(p.id, 'PRODUCT')} className="p-3 text-slate-300 hover:text-rose-500 transition-colors">
                      <Trash2 size={20} />
                    </button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Ürün Ekleme Formu Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4">
          <div className="bg-white w-full max-w-lg rounded-[3rem] p-10 shadow-3xl animate-in zoom-in-95 duration-300">
            <div className="flex justify-between items-center mb-10">
              <h3 className="text-2xl font-black">Yeni Stok Girişi</h3>
              <button onClick={() => setShowForm(false)} className="p-2 hover:bg-slate-100 rounded-full transition-all"><X /></button>
            </div>
            <div className="space-y-6">
              <div>
                <label className="text-xs font-black uppercase text-slate-400 mb-2 block">Ürün Adı</label>
                <input type="text" value={newProd.name} onChange={e => setNewProd({...newProd, name: e.target.value})} className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none font-bold" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-black uppercase text-slate-400 mb-2 block">Maliyet (TL)</label>
                  <input type="number" value={newProd.cost} onChange={e => setNewProd({...newProd, cost: Number(e.target.value)})} className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none font-bold" />
                </div>
                <div>
                  <label className="text-xs font-black uppercase text-slate-400 mb-2 block">Satış (TL)</label>
                  <input type="number" value={newProd.sale} onChange={e => setNewProd({...newProd, sale: Number(e.target.value)})} className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none font-bold" />
                </div>
              </div>
              <div>
                <label className="text-xs font-black uppercase text-slate-400 mb-2 block">Mevcut Stok Adedi</label>
                <input type="number" value={newProd.stock} onChange={e => setNewProd({...newProd, stock: Number(e.target.value)})} className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none font-bold" />
              </div>
              <button onClick={handleAdd} className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-lg hover:bg-black transition-all">Sisteme Kaydet</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
