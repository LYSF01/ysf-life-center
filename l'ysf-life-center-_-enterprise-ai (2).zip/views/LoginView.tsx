
import React, { useState } from 'react';
import { useSalon } from '../store/SalonContext';
import { ShieldCheck, Lock, ArrowRight, MonitorSmartphone } from 'lucide-react';

export const LoginView: React.FC = () => {
  const { login } = useSalon();
  const [pass, setPass] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(pass)) {
      setError(false);
    } else {
      setError(true);
      setPass('');
    }
  };

  return (
    <div className="min-h-screen bg-[#0f172a] flex items-center justify-center p-6 font-['Plus_Jakarta_Sans']">
      <div className="max-w-md w-full">
        <div className="text-center mb-12 animate-in fade-in slide-in-from-bottom-10 duration-1000">
          <div className="w-24 h-24 bg-rose-500 rounded-[2.5rem] flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-rose-500/20 rotate-3 hover:rotate-0 transition-transform cursor-pointer">
            <ShieldCheck size={48} className="text-white" />
          </div>
          <h1 className="text-4xl font-black text-white tracking-tighter mb-2">L'YSF LIFE CENTER</h1>
          <p className="text-slate-400 text-sm font-bold uppercase tracking-[0.3em]">Enterprise Security Cloud</p>
        </div>

        <div className="bg-white/5 backdrop-blur-2xl border border-white/10 p-10 rounded-[3rem] shadow-3xl animate-in zoom-in-95 duration-700">
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <Lock size={12} /> Master Access Key
              </label>
              <input 
                type="password"
                value={pass}
                onChange={(e) => setPass(e.target.value)}
                placeholder="••••••••"
                className={`w-full bg-white/5 border-2 ${error ? 'border-rose-500 animate-shake' : 'border-white/10'} rounded-2xl py-5 px-6 text-white text-2xl font-black tracking-[0.5em] outline-none focus:border-rose-500 transition-all text-center placeholder:tracking-normal placeholder:text-slate-600`}
              />
              {error && <p className="text-rose-500 text-[10px] font-black uppercase text-center mt-2">Hatalı Şifre! Lütfen Tekrar Deneyin.</p>}
            </div>

            <button 
              type="submit"
              className="w-full bg-rose-500 hover:bg-rose-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-rose-500/20 transition-all flex items-center justify-center gap-3 active:scale-95 group"
            >
              Sisteme Güvenli Giriş <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </form>

          <div className="mt-10 pt-8 border-t border-white/5 flex items-center justify-center gap-6 opacity-30">
             <div className="flex items-center gap-2 text-white text-[10px] font-black uppercase">
               <MonitorSmartphone size={14} /> Mobile & PC Ready
             </div>
          </div>
        </div>
        
        <p className="text-center text-slate-600 text-[10px] mt-8 font-black uppercase tracking-widest">LYSF_CLOUD_V4.2.0_SECURED</p>
      </div>
    </div>
  );
};
