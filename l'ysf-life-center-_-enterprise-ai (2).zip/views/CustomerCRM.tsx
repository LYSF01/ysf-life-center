
import React, { useState } from 'react';
import { useSalon } from '../store/SalonContext';
import { MembershipTier } from '../types';
import { User, Phone, Star, History, Trash2, Gift, Activity, Layers, ArrowUpRight } from 'lucide-react';

export const CustomerCRM: React.FC = () => {
  const { customers, deleteData, currentRole, services } = useSalon();
  const [filter, setFilter] = useState('');

  const getTierColor = (tier: MembershipTier) => {
    switch (tier) {
      case MembershipTier.BLACK_VIP: return 'bg-slate-900 text-white';
      case MembershipTier.PLATINUM: return 'bg-indigo-100 text-indigo-700';
      case MembershipTier.GOLD: return 'bg-amber-100 text-amber-700';
      default: return 'bg-slate-100 text-slate-600';
    }
  };

  const filtered = customers.filter(c => c.fullName.toLowerCase().includes(filter.toLowerCase()) || c.phone.includes(filter));

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-100 flex items-center gap-6">
        <div className="w-full relative">
          <input 
            type="text" 
            placeholder="Müşteri ismi veya telefon ile ara..." 
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="w-full p-6 pl-16 bg-slate-50 border-none rounded-3xl outline-none font-black text-slate-700"
          />
          <User className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-8">
        {filtered.map(customer => (
          <div key={customer.id} className="bg-white rounded-[3rem] border border-slate-100 shadow-xl overflow-hidden group hover:shadow-2xl transition-all flex flex-col">
            <div className="p-10 space-y-8 flex-1">
              <div className="flex justify-between items-start">
                <div className="w-20 h-20 bg-slate-900 rounded-[2rem] flex items-center justify-center text-white shadow-xl rotate-3 group-hover:rotate-0 transition-transform">
                  <User size={36} />
                </div>
                <div className={`px-5 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest ${getTierColor(customer.tier)}`}>
                  {customer.tier.replace('_', ' ')}
                </div>
              </div>

              <div>
                <h3 className="text-3xl font-black text-slate-900 tracking-tighter">{customer.fullName}</h3>
                <p className="text-sm font-bold text-slate-400 flex items-center gap-2 mt-2">
                  <Phone size={16} className="text-rose-500" /> {customer.phone}
                </p>
              </div>

              {/* Diyetisyen Verileri */}
              {customer.bodyAnalysis && (
                <div className="bg-emerald-50 p-6 rounded-[2rem] border border-emerald-100 space-y-4">
                   <p className="text-[10px] font-black text-emerald-700 uppercase tracking-widest flex items-center gap-2">
                    <Activity size={14} /> Diyetisyen Analizi
                  </p>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="text-center">
                      <p className="text-[9px] font-black text-emerald-400 uppercase">Kilo</p>
                      <p className="text-lg font-black text-emerald-900">{customer.bodyAnalysis.weight} kg</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[9px] font-black text-emerald-400 uppercase">Yağ %</p>
                      <p className="text-lg font-black text-emerald-900">%{customer.bodyAnalysis.fatRatio}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[9px] font-black text-emerald-400 uppercase">Hedef</p>
                      <p className="text-lg font-black text-emerald-900">{customer.bodyAnalysis.targetWeight} kg</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Seans Paketleri */}
              {customer.packages.length > 0 && (
                <div className="space-y-3">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Layers size={14} className="text-indigo-500" /> Aktif Seanslar
                  </p>
                  <div className="space-y-2">
                    {customer.packages.map((pkg, i) => {
                      const srv = services.find(s => s.id === pkg.serviceId);
                      return (
                        <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                          <span className="text-xs font-black text-slate-700">{srv?.name}</span>
                          <span className="text-xs font-black text-indigo-600 bg-white px-3 py-1 rounded-lg border border-indigo-100">
                            {pkg.remainingSessions} Seans Kaldı
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="p-6 bg-slate-50 rounded-[2rem] border border-slate-100">
                <p className="text-[10px] font-black text-rose-500 uppercase tracking-widest mb-2 flex items-center gap-2">
                  <Gift size={12} /> Özel Notlar
                </p>
                <p className="text-xs text-slate-600 font-bold leading-relaxed italic">{customer.preferences.notes || 'Not eklenmemiş.'}</p>
              </div>
            </div>

            <div className="p-8 border-t border-slate-50 flex items-center justify-between">
              <div className="flex -space-x-2">
                {[1,2,3].map(i => <div key={i} className="w-8 h-8 rounded-full bg-slate-200 border-2 border-white"></div>)}
                <div className="w-8 h-8 rounded-full bg-slate-900 text-[10px] flex items-center justify-center text-white border-2 border-white">+8</div>
              </div>
              {currentRole === 'MANAGER' && (
                <button 
                  onClick={() => { if(confirm("Müşteri kalıcı olarak silinecek?")) deleteData(customer.id, 'CUSTOMER'); }}
                  className="p-4 text-slate-300 hover:text-rose-500 transition-colors"
                >
                  <Trash2 size={20} />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
