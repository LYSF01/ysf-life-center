
import React, { useState, useRef } from 'react';
import { useSalon } from '../store/SalonContext';
import { getGlobalMarketIntelligence, getAIPackageSuggestions } from '../geminiService';
import { Globe, Zap, Loader2, Rocket, UploadCloud, RefreshCw, ArrowDownCircle, CheckCircle2, AlertTriangle } from 'lucide-react';

export const AIAdvice: React.FC = () => {
  const { services, products, importData, exportData, resetToDefaults } = useSalon();
  const [intel, setIntel] = useState<string | null>(null);
  const [packages, setPackages] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchGrowthPlan = async () => {
    setLoading(true);
    const intelligence = await getGlobalMarketIntelligence();
    const pkgResult = await getAIPackageSuggestions(services, products);
    setIntel(intelligence);
    setPackages(pkgResult.packages || []);
    setLoading(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const success = await importData(file);
      if (success) {
         alert("Senkronizasyon Başarılı! Veriler güncellendi.");
         setTimeout(() => window.location.reload(), 500);
      } else {
         alert("Dosya okunamadı. Lütfen indirdiğiniz JSON dosyasını seçin.");
      }
    }
  };

  return (
    <div className="space-y-12 animate-in fade-in duration-700">
      <div className="bg-white p-12 rounded-[4rem] border border-slate-200 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-3 h-full bg-rose-500"></div>
        <div className="flex flex-col xl:flex-row items-center gap-12">
          <div className="w-32 h-32 bg-indigo-50 rounded-[2.5rem] flex items-center justify-center text-indigo-500 shadow-inner">
             <RefreshCw size={56} className="animate-spin-slow" />
          </div>
          <div className="flex-1 text-center xl:text-left">
            <h3 className="text-4xl font-black text-slate-900 mb-4 tracking-tighter">Senkronizasyon ve Veri Yönetimi</h3>
            <p className="text-slate-500 font-bold text-lg max-w-2xl leading-relaxed italic">Verileriniz internete değil, cihazınıza kayıtlıdır. PC'den yedek alın, tablete yükleyin. Bu dükkanınızın güvenliği içindir.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-6 w-full xl:w-auto">
            <button 
              onClick={exportData}
              className="flex-1 xl:flex-none px-12 py-7 bg-slate-900 text-white rounded-[2rem] font-black flex flex-col items-center justify-center gap-2 hover:bg-black transition-all shadow-xl active:scale-95"
            >
              <ArrowDownCircle size={28} />
              <span className="uppercase text-xs tracking-widest">Veriyi Yedekle</span>
            </button>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 xl:flex-none px-12 py-7 bg-rose-500 text-white rounded-[2rem] font-black flex flex-col items-center justify-center gap-2 hover:bg-rose-600 transition-all shadow-xl shadow-rose-500/20 active:scale-95"
            >
              <UploadCloud size={28} />
              <span className="uppercase text-xs tracking-widest">Yedeği Yükle</span>
            </button>
            <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept=".json" />
          </div>
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 pt-10 border-t border-slate-100">
            <div className="flex items-center gap-4 text-slate-600">
              <CheckCircle2 size={24} className="text-emerald-500" />
              <p className="text-sm font-bold">Önce PC'den 'Veriyi Yedekle' butonuna basın.</p>
            </div>
            <div className="flex items-center gap-4 text-slate-600">
              <CheckCircle2 size={24} className="text-emerald-500" />
              <p className="text-sm font-bold">Dosyayı kendinize mail/WhatsApp ile atın.</p>
            </div>
            <div className="flex items-center gap-4 text-slate-600">
              <CheckCircle2 size={24} className="text-emerald-500" />
              <p className="text-sm font-bold">Tabletten 'Yedeği Yükle' deyip o dosyayı seçin.</p>
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <div className="bg-indigo-600 p-12 rounded-[3.5rem] text-white flex flex-col justify-between group hover:bg-indigo-700 transition-all shadow-2xl relative overflow-hidden">
           <div className="absolute top-0 right-0 p-8 opacity-10">
               <Rocket size={100} />
           </div>
           <div className="relative z-10">
            <h3 className="text-3xl font-black text-white mb-6 flex items-center gap-4">
              <Zap /> Global AI Stratejisi
            </h3>
            <p className="text-indigo-100 text-lg font-medium leading-relaxed">
              Berlin, NYC ve İstanbul trendlerini analiz ederek salonunuz için yeni yatırım ve kampanya önerileri sunar.
            </p>
          </div>
          <button 
            onClick={fetchGrowthPlan}
            disabled={loading}
            className="mt-12 w-full bg-white text-indigo-600 font-black py-6 rounded-[2rem] flex items-center justify-center gap-3 shadow-xl hover:scale-105 transition-all disabled:opacity-50"
          >
            {loading ? <Loader2 className="animate-spin" /> : <Globe size={24} />}
            AI Analizini Başlat
          </button>
        </div>

        <div className="bg-rose-50 p-12 rounded-[3.5rem] border border-rose-100 flex flex-col justify-center items-center text-center">
           <AlertTriangle size={64} className="text-rose-500 mb-6 animate-pulse" />
           <p className="text-rose-900 text-xl font-black uppercase tracking-widest mb-4">Veri Temizliği</p>
           <p className="text-rose-600 text-sm font-bold mb-8 max-w-xs">Eğer sistemde bir karışıklık olursa tüm verileri silip fabrika ayarlarına dönebilirsiniz.</p>
           <button 
            onClick={resetToDefaults}
            className="px-8 py-4 bg-rose-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-rose-600 transition-all"
           >
             Fabrika Ayarlarına Dön
           </button>
        </div>
      </div>

      {loading && (
        <div className="flex flex-col items-center justify-center py-32 text-indigo-600">
          <Loader2 size={84} className="animate-spin mb-8" />
          <p className="text-3xl font-black animate-pulse">L'YSF AI Dünyayı Tarıyor...</p>
        </div>
      )}

      {intel && (
        <div className="bg-slate-900 p-16 rounded-[4rem] text-white shadow-3xl animate-in slide-in-from-bottom-12">
            <h3 className="text-4xl font-black mb-10 flex items-center gap-6">
                <Globe className="text-emerald-400" size={48} /> 
                <span className="tracking-tighter">AI PAZAR ZEKASI</span>
            </h3>
            <div className="prose prose-invert prose-2xl max-w-none text-slate-300 font-medium whitespace-pre-wrap leading-relaxed">
                {intel}
            </div>
        </div>
      )}
    </div>
  );
};
