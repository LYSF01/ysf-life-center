
import React, { useState } from 'react';
import { useSalon } from '../store/SalonContext';
import { getAITreatmentProtocol } from '../geminiService';
import { Sparkles, ShoppingBag, Loader2, Send, Award, ListChecks, CheckCircle2, Layers } from 'lucide-react';

export const StaffTerminal: React.FC = () => {
  const { customers, products, services, completeSale, staff, useSession } = useSalon();
  const [selectedCustomer, setSelectedCustomer] = useState(customers[0]?.id || '');
  const [selectedStaff, setSelectedStaff] = useState(staff[0]?.id || '');
  const [observation, setObservation] = useState('');
  const [protocol, setProtocol] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const activeCustomer = customers.find(c => c.id === selectedCustomer);

  const handleProtocol = async () => {
    if (!observation) return;
    setLoading(true);
    const result = await getAITreatmentProtocol(observation, products, services);
    setProtocol(result);
    setLoading(false);
  };

  const handleSale = (serviceId: string, isPackage: boolean = false) => {
    const srv = services.find(s => s.id === serviceId);
    if (!srv) return;
    
    if (isPackage) {
      const sessionCount = prompt("Paket kaç seans olsun?", "10");
      if (!sessionCount) return;
      completeSale(selectedCustomer, selectedStaff, [{ 
        type: 'PACKAGE', 
        id: serviceId, 
        price: srv.price * (Number(sessionCount) * 0.8), // %20 Paket İndirimi
        quantity: 1,
        sessions: Number(sessionCount)
      }]);
    } else {
      completeSale(selectedCustomer, selectedStaff, [{ type: 'SERVICE', id: serviceId, price: srv.price, quantity: 1 }]);
    }
    alert("İşlem başarıyla kaydedildi.");
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-10">
      <div className="xl:col-span-8 space-y-8">
        <div className="bg-white rounded-[3rem] shadow-xl border border-slate-100 overflow-hidden flex flex-col min-h-[800px]">
          <div className="p-10 bg-slate-900 text-white flex items-center justify-between">
            <div className="flex items-center gap-5">
              <div className="p-4 bg-rose-500 rounded-2xl shadow-lg">
                <Sparkles />
              </div>
              <div>
                <h3 className="font-black text-2xl uppercase">Uzman Protokol Sistemi</h3>
                <p className="text-[10px] text-slate-400 font-bold tracking-widest uppercase">L'YSF AI Engine</p>
              </div>
            </div>
            <select 
              value={selectedStaff}
              onChange={e => setSelectedStaff(e.target.value)}
              className="bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-sm font-bold outline-none"
            >
              {staff.map(s => <option key={s.id} value={s.id} className="text-black">{s.name}</option>)}
            </select>
          </div>
          
          <div className="p-10 flex-1 overflow-y-auto bg-slate-50/30 space-y-8">
            <div className="space-y-3">
              <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest px-2">Danışan Seçimi</label>
              <select 
                value={selectedCustomer}
                onChange={(e) => setSelectedCustomer(e.target.value)}
                className="w-full p-5 rounded-2xl bg-white border border-slate-200 font-black outline-none shadow-sm"
              >
                {customers.map(c => <option key={c.id} value={c.id}>{c.fullName} - {c.phone}</option>)}
              </select>
            </div>

            {/* Aktif Paketler Kısmı */}
            {activeCustomer && activeCustomer.packages.length > 0 && (
              <div className="bg-amber-50 p-8 rounded-[2rem] border border-amber-100">
                <h4 className="text-amber-900 font-black text-sm uppercase tracking-widest mb-4 flex items-center gap-2">
                  <Layers size={16} /> Aktif Seans Paketleri
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {activeCustomer.packages.map(pkg => {
                    const srv = services.find(s => s.id === pkg.serviceId);
                    return (
                      <div key={pkg.id} className="bg-white p-5 rounded-2xl border border-amber-200 flex justify-between items-center shadow-sm">
                        <div>
                          <p className="font-black text-slate-900">{srv?.name}</p>
                          <p className="text-xs font-bold text-amber-600">Kalan: {pkg.remainingSessions} / {pkg.totalSessions}</p>
                        </div>
                        <button 
                          onClick={() => {
                            if(confirm("1 seans düşülsün mü?")) useSession(activeCustomer.id, pkg.id);
                          }}
                          disabled={pkg.remainingSessions === 0}
                          className="px-4 py-2 bg-amber-500 text-white rounded-xl font-black text-xs hover:bg-amber-600 transition-all disabled:bg-slate-200"
                        >
                          Seans Kullan
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="space-y-3">
              <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest px-2">Gözlem & Şikayet Notları (AI Analizi)</label>
              <textarea 
                value={observation}
                onChange={(e) => setObservation(e.target.value)}
                placeholder="Örn: Müşterinin cildi çok kuru, Hydrafacial yapılacak. Hangi serumu kullanmalıyım?.."
                className="w-full p-8 h-48 rounded-[2rem] bg-white border border-slate-200 outline-none resize-none font-medium text-lg shadow-sm focus:border-rose-300 transition-colors"
              />
            </div>
            
            <button 
              onClick={handleProtocol}
              disabled={loading || !observation}
              className="w-full bg-slate-900 hover:bg-black text-white font-black py-6 rounded-2xl shadow-2xl transition-all flex items-center justify-center gap-3 disabled:opacity-50"
            >
              {loading ? <Loader2 className="animate-spin" /> : <Send size={20} />}
              Yapay Zekadan Protokol İste
            </button>

            {protocol && (
              <div className="p-10 bg-indigo-50 border-2 border-indigo-100 rounded-[2.5rem] animate-in slide-in-from-bottom-8">
                <h4 className="font-black text-indigo-900 text-xl mb-6 flex items-center gap-3">
                  <ListChecks size={24} /> AI Uygulama Protokolü
                </h4>
                <div className="prose prose-indigo prose-lg text-indigo-900 font-medium whitespace-pre-wrap leading-relaxed italic">
                  {protocol}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="xl:col-span-4 space-y-8">
        <div className="bg-gradient-to-br from-indigo-600 to-indigo-900 p-10 rounded-[3rem] text-white shadow-2xl">
          <div className="flex justify-between items-center mb-10">
            <h4 className="text-xl font-black uppercase">Uzman Performansı</h4>
            <Award className="text-amber-400" />
          </div>
          <div className="space-y-4">
            <div className="bg-white/5 p-6 rounded-3xl border border-white/10">
              <p className="text-[10px] text-indigo-200 uppercase font-black mb-1">Prim Kazancı</p>
              <p className="text-4xl font-black">{(staff.find(s => s.id === selectedStaff)?.totalPrim || 0).toLocaleString()} <span className="text-lg">TL</span></p>
            </div>
          </div>
        </div>

        <div className="bg-white p-10 rounded-[3.5rem] shadow-xl border border-slate-100">
          <h3 className="font-black text-slate-800 text-xl mb-8 flex items-center gap-3">
            <ShoppingBag className="text-rose-500" /> Hizmet & Paket Girişi
          </h3>
          <div className="space-y-3">
            {services.map(s => (
              <div key={s.id} className="group p-5 bg-slate-50 hover:bg-white rounded-2xl border border-transparent hover:border-slate-200 transition-all shadow-sm flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <div className="text-left">
                    <p className="font-black text-slate-900 text-sm">{s.name}</p>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{s.category}</p>
                  </div>
                  <p className="font-black text-rose-500 text-sm">{s.price.toLocaleString()} TL</p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => handleSale(s.id, false)}
                    className="flex-1 py-3 bg-white border border-slate-200 rounded-xl text-[10px] font-black uppercase hover:bg-slate-900 hover:text-white transition-all"
                  >
                    Tek Seans
                  </button>
                  <button 
                    onClick={() => handleSale(s.id, true)}
                    className="flex-1 py-3 bg-rose-50 text-rose-600 rounded-xl text-[10px] font-black uppercase hover:bg-rose-500 hover:text-white transition-all"
                  >
                    Paket Sat
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
