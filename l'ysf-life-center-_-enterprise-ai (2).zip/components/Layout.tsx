
import React, { useState, useEffect } from 'react';
import { useSalon } from '../store/SalonContext';
import { UserRole } from '../types';
import { 
  LayoutDashboard, 
  Users, 
  Package, 
  UserCircle,
  ShoppingBag,
  Settings,
  Zap,
  CalendarDays,
  Download,
  Monitor,
  Globe
} from 'lucide-react';

export const Layout: React.FC<{ children: React.ReactNode; currentTab: string; setTab: (t: string) => void }> = ({ children, currentTab, setTab }) => {
  const { currentRole, setRole, exportData } = useSalon();
  const [installPrompt, setInstallPrompt] = useState<any>(null);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setInstallPrompt(e);
    });
  }, []);

  const handleInstall = () => {
    if (installPrompt) {
      installPrompt.prompt();
    } else {
      alert("Masaüstü için tarayıcı menüsünden 'Uygulama Olarak Yükle' diyebilirsiniz.");
    }
  };

  const navItems = [
    { id: 'dashboard', label: 'Yönetim Üssü', icon: LayoutDashboard, roles: [UserRole.MANAGER] },
    { id: 'appointments', label: 'Randevu Takvimi', icon: CalendarDays, roles: [UserRole.MANAGER, UserRole.STAFF] },
    { id: 'customers', label: 'VIP Müşteri CRM', icon: Users, roles: [UserRole.MANAGER, UserRole.STAFF] },
    { id: 'inventory', label: 'Stok & Güvenlik', icon: Package, roles: [UserRole.MANAGER] },
    { id: 'sales', label: 'Hizmet Girişi', icon: ShoppingBag, roles: [UserRole.STAFF] },
    { id: 'ai-advice', label: 'Büyüme Merkezi', icon: Zap, roles: [UserRole.MANAGER] },
    { id: 'customer-portal', label: 'L\'YSF Tablet', icon: UserCircle, roles: [UserRole.CUSTOMER] },
  ];

  return (
    <div className="flex h-screen bg-[#fcfdfe] overflow-hidden">
      {/* Sidebar */}
      <aside className="w-72 bg-white border-r border-slate-100 flex flex-col z-20 shadow-2xl shadow-slate-200/50">
        <div className="p-10 border-b border-slate-50">
          <h1 className="text-3xl font-black tracking-tighter text-slate-900 flex items-center gap-2">
            L'YSF <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
          </h1>
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.4em] mt-1">Life Center Elite</p>
        </div>

        <nav className="flex-1 p-6 space-y-2 overflow-y-auto">
          {navItems.filter(item => item.roles.includes(currentRole)).map(item => (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`w-full flex items-center gap-4 px-6 py-4 rounded-[1.5rem] text-sm font-black transition-all duration-300 ${
                currentTab === item.id 
                  ? 'bg-slate-900 text-white shadow-xl translate-x-1' 
                  : 'text-slate-400 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <item.icon size={20} strokeWidth={2.5} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-slate-50 space-y-4">
          <div className="flex items-center gap-3 px-4 py-3 bg-emerald-50 rounded-2xl border border-emerald-100">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <span className="text-[10px] font-black text-emerald-700 uppercase tracking-widest">Bulut Aktif</span>
          </div>

          <div className="flex gap-2">
            <button onClick={exportData} title="Yedekle" className="flex-1 flex items-center justify-center p-4 bg-slate-50 text-slate-400 hover:text-indigo-600 rounded-2xl transition-all"><Download size={20} /></button>
            <button onClick={handleInstall} title="Masaüstü" className="flex-1 flex items-center justify-center p-4 bg-slate-50 text-slate-400 hover:text-emerald-600 rounded-2xl transition-all"><Monitor size={20} /></button>
          </div>
          
          <div className="bg-rose-50 p-5 rounded-[2rem] border border-rose-100 shadow-sm shadow-rose-100">
            <p className="text-[10px] uppercase tracking-widest text-rose-400 font-black mb-2">Aktif Rol</p>
            <select 
              value={currentRole}
              onChange={(e) => setRole(e.target.value as UserRole)}
              className="bg-transparent text-sm font-black w-full outline-none cursor-pointer text-rose-900"
            >
              <option value={UserRole.MANAGER}>Yönetici</option>
              <option value={UserRole.STAFF}>Personel</option>
              <option value={UserRole.CUSTOMER}>Müşteri</option>
            </select>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto relative bg-[#fcfdfe]">
        <header className="sticky top-0 z-10 bg-[#fcfdfe]/60 backdrop-blur-3xl px-12 py-8 flex justify-between items-center">
          <h2 className="text-2xl font-black text-slate-900 tracking-tight capitalize">
            {navItems.find(i => i.id === currentTab)?.label || 'Elite Yönetim'}
          </h2>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3 px-4 py-2 bg-white rounded-xl shadow-sm border border-slate-100">
              <Globe size={16} className="text-slate-400" />
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Global Cloud ID: 2904-X</span>
            </div>
            <div className="flex items-center gap-4 pl-6 border-l border-slate-100">
              <div className="text-right">
                <p className="text-sm font-black text-slate-900">Owner / {currentRole}</p>
                <p className="text-[10px] text-emerald-500 font-bold uppercase tracking-widest">Erişim Güvenli</p>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-slate-200 to-slate-300 border-2 border-white shadow-md"></div>
            </div>
          </div>
        </header>
        <div className="px-12 pb-20">
          {children}
        </div>
      </main>
    </div>
  );
};
